#include "stdafx.h"
#include "Game.h"


Game::Game()
{
}


Game::~Game()
{
}

void Game::Run()
{
	this->sceneManager.Run();
}
