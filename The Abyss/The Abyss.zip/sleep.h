#pragma once

namespace std {
	void SkipableSleep(unsigned int milisecond);
}
